//
//  ELVideoCallMessageBody.h
//  ELIMDemo
//
//  Created by 樊小聪 on 2020/4/15.
//  Copyright © 2020 樊小聪. All rights reserved.
//

/*
 *  备注：语音通话消息类型 🐾
 */

#import "ELCallMessageBody.h"

@interface ELVideoCallMessageBody : ELCallMessageBody

@end
